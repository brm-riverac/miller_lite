	var clock = $('.clock').FlipClock(633600, {
		countdown: true
	});