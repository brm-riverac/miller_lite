

$(document).ready(function(){
 $('.single-item').slick();
});
				

				